# BatteryInfoSample
Display Battery Informations including Zebra Specifics KPI
